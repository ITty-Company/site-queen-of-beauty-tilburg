# Queen of Beauty — website (Besterdring 80, Tilburg)

Statische site, klaar voor Cloudflare Workers (assets-only). Idee: «Hartenvrouw» — elke gast trekt een kaart uit de stapel, en eruit komt de hartenvrouw.

## Structuur
- `public/` — de hele site: `index.html`, `behandelingen.html`, `afspraak.html` (configurator «Trek je kaart»), `over-ons.html`, `contact.html`, `404.html`
- `public/assets/` — css (`site.css`), js (`site.js` effecten, `deck.js` Three.js «De Hartenvrouw»), video (scroll-film 1920 + mobiel 900), img, fonts (OFL, lokaal), vendor (GSAP, Lenis, Three.js, motion-kit)
- `_notes/build.py` — genereert de HTML uit de data (tekst/contact) → `python3 _notes/build.py`; `_notes/up.sh` — video-encoding; `_notes/SECTIONS.md` — sectieplan
- `wrangler.jsonc` — Workers-config (name `queen-of-beauty-tilburg`, assets `./public`)

## Publiceren
```bash
npx wrangler login      # eenmalig
npx wrangler deploy     # vanuit deze map
```
Lokaal bekijken: `python3 -m http.server -d public 8080` → http://localhost:8080

## Video
- Hero = LTX (lokaal, c1_v2 + zachte inzoom op k2, ≈3 s) — hero LTX, niet Kling. Proces-film = LTX c2+c4+c5 + inzoom k3 (c3 had een hand); over-ons = LTX c4+c5; finale = LTX c6.

## Nog bevestigen met de zaak (staat bewust neutraal op de site)
- Behandelingen: nu vijf algemene categorieën met «op aanvraag». Exacte lijst, prijzen, namen, e-mail, socials ontbreken.
- Openingstijden: op de site «bel of app». OpenStreetMap noemt ma 12–21, di–vr 10–21, za 9–18, zo dicht — eerst laten bevestigen.
- De afspraak-configurator verstuurt niets: hij maakt een samenvatting en een WhatsApp-bericht dat de klant zelf verstuurt.
- Beelden zijn sfeerbeelden (kaptafel met speelkaarten, geen mensen); echte foto’s vervangen zodra de zaak ze stuurt.
